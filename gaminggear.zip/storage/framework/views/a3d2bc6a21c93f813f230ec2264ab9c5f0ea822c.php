<?php $__env->startSection('title'); ?>
    User Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7 mx-auto">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg">
            <div class="p-5">
              <div class="text-center">
                <?php if(Session::has('danger')): ?>
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="alert alert-danger" role="alert">
                        <?php echo e(Session::get('danger')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <h1 class="h4 text-gray-900 mb-4">Change Account Info !</h1>
              </div>
              <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <form class="md-form" action="<?php echo e(route('user.update',['id' => $u->id])); ?>" method="post">
                    <div class="md-form mb-4">
                        <i class="fas fa-user prefix grey-text"></i>
                        <input type="text" name="name" id="name" class="form-control" value="<?php echo e($u->name); ?>">
                        <label for="name">Nama Lengkap</label>
                    </div>
                    <div class="md-form mb-4">
                        <i class="fas fa-envelope prefix grey-text"></i>
                        <input type="text" name="email" id="email" class="form-control" value="<?php echo e($u->email); ?>">
                        <label for="email">Email</label>
                    </div>
                    <div class="md-form mb-4">
                        <i class="fas fa-lock prefix grey-text"></i>
                        <input type="password" name="password" id="password" class="form-control">
                        <label for="password">Password</label>
                    </div>
                    <div class="md-form">
                        <button type="submit" class="btn btn-outline-info btn-block mx-auto">Change</button>
                        <?php echo e(csrf_field()); ?>

                    </div>
              </form>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gaminggear\resources\views/user/change.blade.php ENDPATH**/ ?>