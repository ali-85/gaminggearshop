<?php $__env->startSection('title'); ?>
    Pending Order
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
  <ul class="nav grey lighten-4 py-4">
      <li class="nav-item">
        <a class="nav-link disabled" href="#!">Transfer</a>
      </li>
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('admin.order')); ?>">Pending</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('admin.order2')); ?>">Dikirim</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('admin.order3')); ?>">Selesai</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#!">Credit Card</a>
      </li>
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('credit.order')); ?>">Pending</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('credit.order')); ?>">Dikirim</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#!">Selesai</a>
      </li>
</ul>
        <div class="card o-hidden border-0 shadow-lg my-5 col-lg-12">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg">
                    <div class="p-2">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">User ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Cart</th>
                                <th scope="col">Alamat</th>
                                <th scope="col">gambar</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($p->user_id); ?></td>
                                <?php $__currentLoopData = $p->cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($item['item']['title']); ?> | <?php echo e($item['qty']); ?> Units</td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($p->name); ?></td>
                                <td><?php echo e($p->address); ?></td>
                                <td><img src="<?php echo e(URL::to('/assets/img/'.$p->image)); ?>" alt="" width="128" height="62"></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#basicExampleModal<?php echo e($p->id); ?>">Kirim</button>
                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </tbody>
                    </table>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
<?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="basicExampleModal<?php echo e($p->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Masukkan NO Resi</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="<?php echo e(route('send',['id' => $p->id])); ?>" method="post">
        <div class="md-form mb-5">
            <input type="text" id="resi" name="resi" class="form-control validate">
            <label data-error="wrong" data-success="right" for="defaultForm-email">Masukkan Resi Pengiriman</label>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-sm btn-primary">Save changes</button>
        <?php echo e(csrf_field()); ?>

      </div>
      </form>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gaminggear\resources\views/admin/order/pending.blade.php ENDPATH**/ ?>