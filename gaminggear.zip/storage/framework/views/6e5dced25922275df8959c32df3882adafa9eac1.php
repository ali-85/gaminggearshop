<?php $__env->startSection('title'); ?>
    User Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
  <div class="col-lg-3">
  <ul class="list-group mt-5">
    <li class="list-group-item"><a href="<?php echo e(route('user.change')); ?>">Change Account Info</a></li>
    <li class="list-group-item"><a href="<?php echo e(route('user.changePass')); ?>">Change Password</a></li>
  </ul>
  </div>
    <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg">
            <div class="p-5">
              <div class="text-center">
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h1 class="h4 text-gray-900 mb-4">User Profile !</h1>
              </div>
              <p class="">Nama : <?php echo e($u->name); ?></p>
              <p class="">Email : <?php echo e($u->email); ?></p>
              <p class="">Terakhir diupdate : <?php echo e($u->updated_at->format('d/m/Y')); ?></p>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gaminggear\resources\views/user/profile.blade.php ENDPATH**/ ?>