<?php $__env->startSection('title'); ?>
    Sign Up
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7 mx-auto">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg">
            <div class="p-5">
              <div class="text-center">
              <?php if(Session::has('danger')): ?>
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="alert alert-danger" role="alert">
                        <?php echo e(Session::get('danger')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
              </div>
              <form class="user" method="post" action="<?php echo e(route('user.signup')); ?>">
              <div class="md-form">
                  <input type="text" class="form-control" id="name" name="name">
                  <label for="name">Full Name</label>
                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                      <div class="alert alert-danger alert-dismissible fade show"><?php echo e($message); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="md-form">
                  <input type="text" class="form-control" id="email" name="email">
                  <label for="email">Email</label>
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                      <div class="alert alert-danger alert-dismissible fade show"><?php echo e($message); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="md-form">
                    <input type="password" class="form-control" id="password" name="password">
                    <label for="password">Password</label>
                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                      <div class="alert alert-danger alert-dismissible fade show"><?php echo e($message); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <button type="submit" class="btn btn-primary btn-block mx-auto">
                  Register Account
                </button>
                <?php echo e(csrf_field()); ?>

              </form>
              <hr>
              <div class="text-center">
                <a class="small" href="<?php echo e(route('user.forgot')); ?>">Forgot Password?</a>
              </div>
              <div class="text-center">
                <a class="small" href="<?php echo e(route('user.signin')); ?>">Already have an account? Login!</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gaminggear\resources\views/user/signup.blade.php ENDPATH**/ ?>