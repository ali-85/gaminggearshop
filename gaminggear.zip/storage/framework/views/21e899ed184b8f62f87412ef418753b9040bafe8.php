<?php $__env->startSection('title'); ?>
    GamingGear
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        @media  only screen and (max-width: 576px) {
            .d-block{
                height: 200px;
            }
        }
        .d-block{
            max-height: 400px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <div id="carouselExampleControls" class="carousel slide carousel-fade" data-ride="carousel" data-interval="4000">
            <ol class="carousel-indicators">
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($loop->index); ?>" class="active"></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
            <div class="carousel-inner" role="listbox">
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                    <a href="<?php echo e($s->link); ?>">
                    <img class="d-block w-100" src="<?php echo e(URL::to('assets/img/carousel/'.$s->image)); ?>" alt="<?php echo e($s->title); ?>">
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <div class="container">
        <?php if(Session::has('success')): ?>
        <div class="row mt-3">
            <div class="col-lg-12">
                <div id="purchase-message" class="alert alert-success text-center" role="alert">
                    <?php echo e(Session::get('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php if(Session::has('status')): ?>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mt-3">
                <li class="breadcrumb-item"><a href="<?php echo e(route('product.index')); ?>">Home</a></li>
                <li class="breadcrumb-item active"><?php echo e(Session::get('status')); ?></li>
            </ol>
        </nav>
        <?php endif; ?>
        <div class="row mt-3">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4 mt-2">
                <div class="card" style="width: 18rem;">
                <div class="view overlay">
                    <img class="img-thumbnail" src="<?php echo e(URL::to('assets/img/'.$p->imagePath)); ?>" alt="Card image cap" width="800" height="800">
                    <a href="<?php echo e(route('product.detail',['id' => $p->id])); ?>">
                    <div class="mask rgba-white-slight"></div>
                    </a>
                </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('product.detail',['id' => $p->id])); ?>" name="$p->title">
                            <h5 class="card-title font-weight-bold"><?php echo e($p->title); ?></h5>
                        </a>
                        <p><h6 class="text-gray font-weight-bold float-left mt-2">Rp. <?php echo number_format($p->price, 0, ',', '.'); ?></h6>
                        <a href="<?php echo e(route('product.AddtoCart',['id' => $p->id])); ?>" class="btn btn-primary btn-sm float-right" role="button">Add to Cart</a></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gaminggear\resources\views/shop/index.blade.php ENDPATH**/ ?>