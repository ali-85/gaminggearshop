<?php $__env->startSection('title'); ?>
    Transfer Method
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7 mx-auto">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg">
            <div class="p-5">
              <a href="<?php echo e(route('checkout')); ?>"><i class="fas fa-arrow-left"></i> Credit Card</a>
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Checkout!</h1>
                <h5 class="h5 text-gray-900">Your Total : Rp. <?php echo number_format($total, 0, ',', '.'); ?></h5>
                <div id="charge-error" class="alert alert-danger <?php echo e(!Session::has('error') ? 'hidden' : ''); ?>" role="alert"><?php echo e(Session::get('error')); ?></div>
              </div>
              <form action="<?php echo e(route('transfer.postcheckout')); ?>" method="post" method="post" enctype="multipart/form-data">
                <div class="form-group">
                  <input type="text" class="form-control form-control-user" id="name" name="name" placeholder="Full Name" value="<?php echo e(Auth::user()->name); ?>">
                </div>
                <div class="form-group">
                    <textarea class="form-control" id="address" name="address" rows="3" placeholder="Address"></textarea>
                </div>
                <p> Transfer to : 4444-4444-4444</p>
                <div class="input-group mb-3">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="image"
                        aria-describedby="inputGroupFileAddon01" name="image">
                        <label class="custom-file-label" for="inputGroupFile01">Pilih Bukti Transfer</label>
                    </div>
                </div>
                <button type="submit" class="btn btn-success btn-block mx-auto">
                  Transfer
                </button>
                <?php echo e(csrf_field()); ?>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gaminggear\resources\views/shop/transfer.blade.php ENDPATH**/ ?>