<nav class="navbar sticky-top navbar-expand-lg navbar navbar-dark bg-primary shadow-sm">
  <a class="navbar-brand" href="<?php echo e(route('product.index')); ?>" style="font-family:Roboto;">GamingGear</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <?php if(Auth()->check() && Auth::user()->role == 1): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('admin.allproduct')); ?>"><i class="far fa-fw fa-list-alt"></i> Manage Products
        </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('admin.slider')); ?>"><i class="fas fa-fw fa-tv"></i> Manage Slider
        </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('admin.order')); ?>"><i class="fas fa-fw fa-clipboard-list"></i> Manage Orders
        </a>
        </li>
      <?php endif; ?>
    <form class="form-inline" action="<?php echo e(route('product.search')); ?>">
      <input id="searchNav" class="form-control" type="search" placeholder="Search" aria-label="Search" name="keyword">
      <button class="btn btn-outline-white btn-md my-2 my-sm-0" type="submit">Search</button>
    </form>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('product.cart')); ?>"><i class="fas fa-fw fa-shopping-cart" aria-hidden="true"></i> Shopping cart 
        <span class="badge badge-pill badge-light"><?php echo e(Session::has('cart') ? Session::get('cart')->totalQty : ''); ?></span>
      </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-user" aria-hidden="true"></i> User Management
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <?php if(Auth::check()): ?>
            <a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>">My Profile</a>
            <a class="dropdown-item" href="<?php echo e(route('user.order')); ?>">My Order</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>">Logout</a>
          <?php else: ?>
            <a class="dropdown-item" href="<?php echo e(route('user.signin')); ?>">Sign In</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route('user.signup')); ?>">Sign Up</a>
          <?php endif; ?>
        </div>
      </li>
    </ul>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\gaminggear\resources\views/partials/header.blade.php ENDPATH**/ ?>