<?php $__env->startSection('title'); ?>
    All Order
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-lg-3">
        <ul class="list-group mt-5">
            <li class="list-group-item"><a href="<?php echo e(route('user.change')); ?>">Pending</a></li>
            <li class="list-group-item"><a href="<?php echo e(route('user.changePass')); ?>">Dikirim</a></li>
            <li class="list-group-item"><a href="<?php echo e(route('user.changePass')); ?>">Selesai</a></li>
        </ul>
        </div>
        <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg">
                        <div class="p-5">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">User Profile !</h1>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gaminggear\resources\views/admin/order.blade.php ENDPATH**/ ?>