<?php $__env->startSection('title'); ?>
    My Order
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
  <ul class="nav grey lighten-4 py-4">
      <li class="nav-item">
        <a class="nav-link disabled" href="#!">Metode Bayar</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('user.order')); ?>">Credit Card</a>
      </li>
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('user.order2')); ?>">Transfer</a>
        </li>
</ul>
    </div>
    <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7 mx-auto">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">My Orders !</h1>
              </div>
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <ul class="list-group">
                            <?php $__currentLoopData = $order->cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <span class="badge badge-info text-white">Rp. <?php echo number_format($item['price'], 0, ',', '.'); ?></span>
                                <?php echo e($item['item']['title']); ?> | <?php echo e($item['qty']); ?> Units
                                <?php if($order->status == 2): ?>
                                <form action="<?php echo e(route('cc.finish',['id' => $order->id])); ?>" method="post">
                                <button class="btn btn-sm btn-success float-right">Selesai</button>
                                <?php echo e(csrf_field()); ?>

                                </form>
                                <?php elseif($order->status == 3): ?>
                                <h5>Order Selesai</h5>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <div class="panel-footer">
                        <?php if($order->status == "pending"): ?>
                        <strong>Status: Menunggu Diproses Admin</strong>
                        <?php elseif($order->status == 2): ?>
                        <?php $__currentLoopData = $resic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <strong>Status: Sedang Dikirim | Resi : <a href="https://cekresi.com/cek-jne-express-logistic.php?noresi=<?php echo e($rc->resi); ?>" target="_blank"><?php echo e($rc->resi); ?></a></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gaminggear\resources\views/user/order.blade.php ENDPATH**/ ?>