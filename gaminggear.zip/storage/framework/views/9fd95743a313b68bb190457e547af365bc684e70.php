<?php $__env->startSection('title'); ?>
    Pending Order
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
  <ul class="nav grey lighten-4 py-4">
      <li class="nav-item">
        <a class="nav-link disabled" href="#!">Transfer</a>
      </li>
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('admin.order')); ?>">Pending</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('admin.order2')); ?>">Dikirim</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('admin.order3')); ?>">Selesai</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#!">Credit Card</a>
      </li>
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('credit.order')); ?>">Pending</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('credit.order2')); ?>">Dikirim</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('credit.order3')); ?>">Selesai</a>
      </li>
</ul>
        <div class="card o-hidden border-0 shadow-lg my-5 col-lg-12">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg">
                    <div class="p-2">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">User ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Cart</th>
                                <th scope="col">Alamat</th>
                                <th scope="col">gambar</th>
                                <th scope="col">Resi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($p->user_id); ?></td>
                                <?php $__currentLoopData = $p->cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($item['item']['title']); ?> | <?php echo e($item['qty']); ?> Units</td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($p->name); ?></td>
                                <td><?php echo e($p->address); ?></td>
                                <td><?php echo e($p->payment_id); ?></td>
                                <?php $__currentLoopData = $resi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <a href="https://cekresi.com/cek-jne-express-logistic.php?noresi=<?php echo e($r->resi); ?>" target="_blank"><?php echo e($r->resi); ?></a>
                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </tbody>
                    </table>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gaminggear\resources\views/admin/order/kirim2.blade.php ENDPATH**/ ?>