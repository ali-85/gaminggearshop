<?php $__env->startSection('title'); ?>
    Shopping Cart
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('cart')): ?>
        <div class="container">
            <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7 mx-auto">
                <div class="card-body p-0">
                    <div class="row">
                        <div class="col-lg">
                            <div class="p-5">
                                <ul class="list-group">
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            <span class="badge badge-default"><?php echo e($p['qty']); ?></span>
                                            <strong><?php echo e($p['item']['title']); ?></strong>
                                            <span class="badge badge-success">Rp. <?php echo number_format($p['price'], 0, ',', '.'); ?></span>
                                            <a href="<?php echo e(route('product.remove',['id' => $p['item']['id']])); ?>" class="badge badge-danger float-right ml-2" role="button"><i class="fas fa-trash"></i></a>
                                            <a href="<?php echo e(route('product.reduce',['id' => $p['item']['id']])); ?>" class="badge badge-secondary float-right" role="button"><i class="fas fa-minus"></i></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-md-4">
                            <strong>Total: Rp. <?php echo number_format($totalPrice, 0, ',', '.'); ?></strong>
                        </div>
                    </div>
                    <hr>
                    <div class="row mb-3">
                        <div class="col-sm-6 col-md-4">
                            <a href="<?php echo e(route('checkout')); ?>" class="btn btn-success" role="button">Checkout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
    <div class="container">
        <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7 mx-auto">
            <div class="card-body p-0">
                <div class="row mt-3">
                    <div class="col-lg">
                        <div class="p-5">
                            <div class="text-center">
                                <h4>No item in Shopping Cart !</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <?php $__currentLoopData = $get; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4 mt-2">
                <div class="card" style="width: 18rem;">
                <div class="view overlay">
                    <img class="img-thumbnail" src="<?php echo e(URL::to('assets/img/'.$p->imagePath)); ?>" alt="Card image cap">
                    <a href="<?php echo e(route('product.detail',['id' => $p->id])); ?>">
                    <div class="mask rgba-white-slight"></div>
                    </a>
                </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('product.detail',['id' => $p->id])); ?>" name="$p->title">
                            <h5 class="card-title font-weight-bold"><?php echo e($p->title); ?></h5>
                        </a>
                        <p><h6 class="text-gray font-weight-bold float-left mt-2">Rp. <?php echo number_format($p->price, 0, ',', '.'); ?></h6>
                        <a href="<?php echo e(route('product.AddtoCart',['id' => $p->id])); ?>" class="btn btn-primary btn-sm float-right" role="button">Add to Cart</a></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gaminggear\resources\views/shop/cart.blade.php ENDPATH**/ ?>