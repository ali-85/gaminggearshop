<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Resi extends Model
{
    protected $fillable = ['transfer_id','credit_id','resi'];
}
